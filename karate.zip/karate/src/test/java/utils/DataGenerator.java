package utils;

import com.github.javafaker.Faker;

import java.util.Locale;



public class DataGenerator {

    public static String getRandomSalaryBand(){
        Faker faker = new Faker();
        String salaryBand = faker.letterify("Project Leader8").toString() + faker.random().nextInt(0,100);
        return salaryBand;

    }
}
