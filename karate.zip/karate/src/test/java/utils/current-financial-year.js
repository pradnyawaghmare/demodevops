function getCurrentFinancialYear() {
  var financial_year = "";
  var today = new Date();
  if ((today.getMonth() + 1) <= 3) {
    financial_year = (today.getFullYear() - 2)
  } else {
    financial_year = (today.getFullYear() - 1)
  }
  return financial_year;
}