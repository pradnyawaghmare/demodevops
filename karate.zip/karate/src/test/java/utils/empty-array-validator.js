function fn(s){
    	     
  if(s.length > 0)
   return true;
   else
   return false; 
 
 }
       
 