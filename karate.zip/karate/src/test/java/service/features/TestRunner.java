package service.features;

import static org.junit.Assert.*;
import java.io.File;
import java.io.FileNotFoundException;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import org.junit.Test;

import org.apache.commons.io.FileUtils;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.Results;
import com.intuit.karate.Runner;
//import com.intuit.karate.junit4.Karate

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

@KarateOptions(tags = { "@debug", "@regression" , "@negative", "@smoke", "@positive", "@sanity" })

public class TestRunner {
	static String projectName = "HRPlatform-API-Automation";
	@Test
	public void testParallel() {
		File file = new File("target/surefire-reports/");
		
		String[] myFiles;
		if (file.isDirectory()) {
			myFiles = file.list();
			for (int i = 0; i < myFiles.length; i++) {
				File myFile = new File(file, myFiles[i]);
				System.out.println("deleting files" + myFile);
				myFile.delete();
			}
		}

		String karateOutputPath = "target/surefire-reports";
		long starttime = System.nanoTime();
		Results results = Runner.parallel(getClass(), 2, karateOutputPath);
		long endtime = System.nanoTime();
		/**
		 * below given code will calculate the exec time
		 ***/
		long duration = (endtime - starttime);
		double exec_time = ((double) duration / 1000000000);

		double exec_time_min = ((double) exec_time / 60);
		String project_path = System.getProperty("user.dir");
		double value = 60.00;
		PrintWriter writer;
		DecimalFormat df = new DecimalFormat("#.###");
		try {
		   writer = new PrintWriter(project_path + "/time.txt", "UTF-8");
		   if (exec_time <= value) {
				writer.println(df.format(exec_time));
	} else {
				writer.println(df.format(exec_time_min) + "min");
			}
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		try {
			generateReport(karateOutputPath);
			assertTrue(results.getErrorMessages(), results.getFailCount() == 0);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void generateReport(String karateOutputPath) {
		String project_path = System.getProperty("user.dir");

		Date now = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyhhmmss");
		String time = dateFormat.format(now);
		File dir = new File(time);
		Collection<File> jsonFiles = FileUtils.listFiles(new File(karateOutputPath), new String[] { "json" }, true);
		List<String> jsonPaths = new ArrayList<String>(jsonFiles.size());
		jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
		Configuration config = new Configuration(new File("target/reports/" + dir), projectName);
		config.addClassifications("Platform", "Windows");
		config.addClassifications("Browser", "Chrome");
		config.addClassifications("Branch", "release/1.0");
		System.out.println(project_path + "/target/reports/" + dir + "/cucumber-html-reports/overview-features.html");
		ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
		reportBuilder.generateReports();
		
        
	}
	
	

}
