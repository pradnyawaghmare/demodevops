const mongoose = require('mongoose')
const config = require('../../config/config')
const MONGO_URL = require('./mongoConnectionURL').mongoURL()

console.log("MONGO_URL: ", MONGO_URL)

mongoose.connect(MONGO_URL, config.MONGO_OPTIONS).then(() => {
    console.log('MongoDb connected')
}).catch((err) => {
    console.log("mongoose.connect error")
    console.error(err)
})
mongoose.Promise = global.Promise
const mongodb = mongoose.connection
// CONNECTION EVENTS
// When successfully connected
mongodb.on('connected', function () {
    console.log('Mongoose default connection open to ' + MONGO_URL)
})
// If the connection throws an error
mongodb.on('error', function (err) {
    console.log('Mongoose default connection error: ' + err)
})
// When the connection is disconnected
mongodb.on('disconnected', function () {
    console.log('Mongoose default connection disconnected')
})
// If the Node process ends, close the Mongoose connection
process.on('SIGINT', function () {
    mongodb.close(function () {
        console.log('Mongoose default connection disconnected through app termination')
        process.exit(0)
    })
})
module.exports = {
    mongodb,
}




// mongodb://scmpuser:D3VsCmPfIamv3c0mp13x@10.26.24.104:27017/?authSource=SCMPF&readPreference=primary&appname=MongoDB%20Compass&ssl=false

// mongodb://scmpuser:D3VsCmPfIamv3c0mp13x@10.26.24.104:27017/SCMPF?useNewUrlParser=true&checkKeys=false&useCreateIndex=true&useUnifiedTopology=true

