const config = require('../../../config/config')

const mongoURL = (mongoDB) => {
    // Set up mongo connection
    const MONGO_USER = config.MONGO_USER
    const MONGO_PWD = config.MONGO_PWD
    let MONGO_CREDENTIALS = null
    if (MONGO_USER && MONGO_PWD) {
        const MONGO_USER_ENCODED = encodeURIComponent(MONGO_USER)
        const MONGO_PWD_ENCODED = encodeURIComponent(MONGO_PWD)
        MONGO_CREDENTIALS = `${MONGO_USER_ENCODED}:${MONGO_PWD_ENCODED}`
    }
    let MONGO_URL = config.MONGO_URL
    if (MONGO_CREDENTIALS) {
        MONGO_URL = `${MONGO_URL.split('://')[0]}://${MONGO_CREDENTIALS}@${MONGO_URL.split('://')[1]}`
    }
    const MONGO_DB = mongoDB || config.MONGO_DB
    // const MONGO_OPTIONS = config.MONGO_OPTIONS
    // const MONGO_OPTIONS = mongoDB?(`${config.MONGO_URI_OPTIONS_UPDATED}&authSource=${mongoDB}`):config.MONGO_URI_OPTIONS
    const MONGO_OPTIONS = config.MONGO_URI_OPTIONS_UPDATED
    MONGO_URL = MONGO_URL + MONGO_DB + MONGO_OPTIONS
    console.log(MONGO_URL)
    return MONGO_URL
}

module.exports = {
    mongoURL
}
