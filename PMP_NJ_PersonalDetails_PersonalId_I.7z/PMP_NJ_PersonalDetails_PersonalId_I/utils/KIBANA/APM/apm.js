const config = require('../../../config/config');

module.exports = {
	serviceName                : config.serviceName,
	serverUrl                  : config.serverUrl,
	active                     : true,
	instrument                 : true,
	asyncHooks                 : true,
	captureBody                : 'all',
	errorOnAbortedRequests     : false,
	abortedErrorThreshold      : 25000,
	transactionSampleRate      : 1.0,
	frameworkName              : 'elastic-apm-node',
	frameworkVersion           : '7.4.2',
	logLevel                   : 'info',
	captureExceptions          : true,
	captureErrorLogStackTraces : 'messages',
	captureSpanStackTraces     : true,
	errorMessageMaxLength      : 2048,
	stackTraceLimit            : 50,
	transactionMaxSpans        : 500,
	flushInterval              : 10,
	serverTimeout              : 30,
	maxQueueSize               : 100,
	filterHttpHeaders          : true,
	globalLabels               : {
		platform       : 'PeoplePlatform',
		sub_platform   : 'PersonalDetails',
		application    : 'PMP_NJ_PersonalDetails_PersonalId_I',
		component_name : 'PMP_NJ_PersonalDetails_PersonalId_I',
		component_type : 'Interface API'
	}
};
