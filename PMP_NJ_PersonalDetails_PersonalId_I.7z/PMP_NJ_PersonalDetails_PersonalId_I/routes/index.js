const express = require('express');
const router = express.Router();
const config = require('../config/config');
const getUrlPrefix = config.app.prefix;
console.log('getUrlPrefix: ', getUrlPrefix);
const getDataController = require('../controller/getData');
const produceDataController = require('../controller/produceData');
const noderfcController = require('../controller/noderfc');
const postODataController = require('../controller/postOData');
const getLicenseDetailsController = require('../controller/getLicenseDetails');
const getVisaDetailsController = require('../controller/getVisaDetails');
const savePanDetailsController = require('../controller/savePanDetails');
const getPanDetailsController = require('../controller/getPanDetails');
const getAdharDetailsController = require('../controller/getAdharDetails');
const getPassportDetailsController = require('../controller/getPassportDetails');
const getPersonalIDAttachmentListController = require('../controller/getPersonalIDAttachmentList');
const saveAadharDetailsController = require('../controller/saveAadharDetails');
const saveVisaDetailsController = require('../controller/saveVisaDetails');
const savePassportDetailsController = require('../controller/savePassportDetails');
const getDrivingLicensetypesController = require('../controller/getDrivingLicensetypes')
const saveLicenseController = require('../controller/saveLicense')
const updateLicenseController = require('../controller/updateLicense')

const middleware = require('../services/middleware');

// router.use(async function bodyValidateFnc(req, res, next) {
// 	let bodyValResposne = await middleware.validateReq(req, res, next);
// 	if (bodyValResposne == true) {
// 		next();
// 	}
// });

router.use(async function middlewareFnc(req, res, next) {
	let authResposne = await middleware.validateCookie(req, res, next);
	if (authResposne == true) {
		next();
	}
});

var multer = require('multer');
var storage = multer.memoryStorage();
var uploadService = multer({
	storage : storage
});

/* GET home page. */
router.get(getUrlPrefix + '/ping', (req, res, next) => {
	res.status(200).send('pong');
});

router.post(getUrlPrefix + '/getData', (req, res) => {
	getDataController.getDetails(req, res);
});

router.post(getUrlPrefix + '/produceData', (req, res, next) => {
	produceDataController.produceIntoKafka(req, res);
});

router.post(getUrlPrefix + '/noderfc', (req, res, next) => {
	noderfcController.noderfc(req, res);
});

router.post(getUrlPrefix + '/postOData', (req, res, next) => {
	postODataController.saveNodeOData(req, res);
});

router.get(getUrlPrefix + '/getLicenseDetailsController', middleware.validateReq, (req, res, next) => {
	getLicenseDetailsController.getLicenseDetails(req, res);
});

router.get(getUrlPrefix + '/getVisaDetailsController', middleware.validateReq, (req, res, next) => {
	getVisaDetailsController.getVisaDetails(req, res);
});

router.post(getUrlPrefix + '/savePanDetails', uploadService.array('uploadFiles'), middleware.validateReq, middleware.filecheck, (req, res, next) => {
	savePanDetailsController.savePanDetails(req, res);
});

router.get(getUrlPrefix + '/pan/detail', middleware.validateReq, (req, res, next) => {
	getPanDetailsController.getPanDetails(req, res);
});

router.get(getUrlPrefix + '/aadhaar/detail', middleware.validateReq, (req, res, next) => {
	getAdharDetailsController.getAdharDetails(req, res);
});

router.get(getUrlPrefix + '/passport/detail', middleware.validateReq, (req, res, next) => {
	getPassportDetailsController.getPassportDetails(req, res);
});

router.get(getUrlPrefix + '/getPersonalIDAttachmentList', middleware.validateReq, (req, res, next) => {
	getPersonalIDAttachmentListController.getPersonalIDAttachmentList(req, res);
});

router.post(getUrlPrefix + '/aadhaar/save', uploadService.array('uploadFiles'), middleware.validateReq, middleware.filecheck, (req, res, next) => {
	saveAadharDetailsController.saveAadharDetails(req, res);
});

router.post(getUrlPrefix + '/saveVisaDetails', uploadService.array('uploadFiles'), middleware.validateReq, middleware.filecheck, (req, res, next) => {
	saveVisaDetailsController.saveVisaDetails(req, res);
});

router.post(getUrlPrefix + '/savePassportDetails', uploadService.array('uploadFiles'), middleware.validateReq, middleware.filecheck, (req, res, next) => {
	savePassportDetailsController.savePassportDetails(req, res);
});
router.get(getUrlPrefix + '/getDrivingLicensetypes', middleware.validateReq, (req, res, next) => {
	getDrivingLicensetypesController.getDrivingLicensetypes(req, res);
});

router.post(getUrlPrefix + '/saveLicense', uploadService.array('uploadFiles'), middleware.validateReq, middleware.filecheck, (req, res, next) => {
	saveLicenseController.saveLicense(req, res);
});

router.post(getUrlPrefix + '/updateLicense', uploadService.array('uploadFiles'), middleware.validateReq, middleware.filecheck, (req, res, next) => {
	updateLicenseController.updateLicense(req, res);
});

module.exports = router;
