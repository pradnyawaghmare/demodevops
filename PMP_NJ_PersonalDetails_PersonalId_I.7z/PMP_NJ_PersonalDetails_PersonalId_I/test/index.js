let chai = require('chai');
const expect = require('chai').expect;
let chaiHttp = require('chai-http');
let app = require('../app');
let should = chai.should();
chai.use(chaiHttp);
//Our parent block
/*
  * Test the /GET route
  */
describe('Mocha Testing', function() {
	let Cookie =
		'MYSSO=4e878abbe30847dbfaf6abbd52349a038639bf0f30bb0156b0621b8c2c578da871c994e0e95a6972a62438302dbe34f8e5972d2d312d9793ff7c48e31ad531ce8aecc819c9783428a5059ec11d6a9ad923635f10d023210199e679f97327b476c7bb9d7fe8c226ad33e3ec8ee6527670acad38911b94ab3603d0fce537cfa98e2684c8d1d32f97a5e1f43d05d624bff906bb014715f69ffb17e9a559bd13c6fc06300dd622be00ffba3e38a24731090fbe7dcfc4543b9c93b18d67a0f2a95897fd5446dfe2bf0b8bb88a2ae806da24d0e5449714050124b61de1c2bd4a3cf2b1f2fc152ec43fd9e9669191cdc7f2d55d264a69372a771b15b8c0439e894ef9ebf031e429759811440c95a75323727a216c75da0cb9272964218f3cce36210b080c56db3f210f3d838e46daf4e8ef1a81f359a4e82cbb0cd4af44fb8521c724f818e6affcfec068a2fe22c1425930fedd; USER=%7B%22domain_id%22%3A%22hitesh%20kharti%22%2C%22email%22%3A%22test.separation%40ril.com%22%2C%22fullname%22%3A%22Hitesh%20Kharti%22%2C%22env%22%3A%22dev%22%2C%22business_unit%22%3A%22HC%22%2C%22internal%22%3Atrue%7D; MYSAPSSO2=AjQxMDMBABhQADEAOQA1ADAANwA0ADQAMAAgACAAIAACAAYxADgANgADABBOAEcARAAgACAAIAAgACAABAAYMgAwADIAMQAwADYAMQA3ADAAOAAwADkABQAEAAAACAkAAkUA%2fwFWMIIBUgYJKoZIhvcNAQcCoIIBQzCCAT8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGCAR4wggEaAgEBMHAwZDELMAkGA1UEBhMCREUxHDAaBgNVBAoTE1NBUCBUcnVzdCBDb21tdW5pdHkxEzARBgNVBAsTClNBUCBXZWIgQVMxFDASBgNVBAsTC0kwMDIwMjYwNjU5MQwwCgYDVQQDEwNOR0QCCAogIAUFEEkBMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMTA2MTcwODA5MjZaMCMGCSqGSIb3DQEJBDEWBBRcGldZ4GhDlXN4VWr6010%21v8xjkjAJBgcqhkjOOAQDBC4wLAIUL25OMzcjH3ZQJCrpbWRReKqocJACFBZnS%21lPsZVKcmFeh%21Rw92Cuvxu0; SAP_SESSIONID_NGD_186=HYs4lwpv23mVWUQRtLUbh1SDzTbPQxHrgNoAUFaYdTM%3d; PMP_NJ_Mysso_DEV.sid=s%3ASeCKzkPGLq4Ga2BrWnm_-ri3TIeiFh3D.8WwV9ajgXkQMQtRQCqYTQj%2BTnyR%2BDILUpxuZIBVv7P0; buIdentifier=HYD; BIGipServerHRPF-DEV-POOL-31380=rd40o00000000000000000000ffff0a1a18f9o31380'
	it('getLicenseDetails success Get Call', (done) => {
		chai.request(app).get('/api/personaldetails-personalid-i/getLicenseDetailsController').set('cookie', Cookie).end((errld, resld) => {
			if (errld) done(errld);
			resld.should.have.status(200);
			resld.body.should.be.a('array');
			done();
		});
	});

	it('getVisaDetails success Get Call', (done) => {
		chai.request(app).get('/api/personaldetails-personalid-i/getVisaDetailsController').set('cookie', Cookie).end((errvd, resvd) => {
			if (errvd) done(errvd);
			resvd.should.have.status(200);
			resvd.body.should.be.a('object');
			done();
		});
	});
	it('getPan detail success Get Call', (done) => {
		chai.request(app).get('/api/personaldetails-personalid-i/pan/detail').set('cookie', Cookie).end((pderr, pdres) => {
			if (pderr) done(pderr);
			pdres.should.have.status(200);
			pdres.body.should.be.a('object');
			done();
		});
	});
	it('getAdhar detail success Get Call', (done) => {
		chai.request(app).get('/api/personaldetails-personalid-i/aadhaar/detail').set('cookie', Cookie).end((aderr, adres) => {
			if (aderr) done(aderr);
			adres.should.have.status(200);
			adres.body.should.be.a('object');
			done();
		});
	});
	it('getPassport detail success Get Call', (done) => {
		chai.request(app).get('/api/personaldetails-personalid-i/passport/detail').set('cookie', Cookie).end((ppderr, ppdres) => {
			if (ppderr) done(ppderr);
			ppdres.should.have.status(200);
			ppdres.body.should.be.a('object');
			done();
		});
	});
	it('getPersonalIDAttachmentList success Get Call', (done) => {
		chai
			.request(app)
			.get('/api/personaldetails-personalid-i/getPersonalIDAttachmentList')
			.query({ type: 'AADHAAR' })
			.set('cookie', Cookie)
			.end((aadharErr, aadharRes) => {
				if (aadharErr) done(aadharErr);
				aadharRes.should.have.status(200);
				aadharRes.body.should.be.a('array');
				done();
			});
	});
	it('getDrivingLicensetypes success Get Call', (done) => {
		chai
			.request(app)
			.get('/api/personaldetails-personalid-i/getDrivingLicensetypes')
			.set('cookie', Cookie)
			.end((dlErr, dlRes) => {
				if (dlErr) done(dlErr);
				dlRes.should.have.status(200);
				dlRes.body.should.be.a('array');
				done();
			});
	});
});
