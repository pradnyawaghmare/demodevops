/**
 * function is for calling service api to fetch Data
 * creating unqid and datetime to add into logger
 */
const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
let config = require('../config/config')
let log = require('./loggerFunction').log
let postServiceCall = require('./commmon').postServiceCall

function getData(payload) {
    let deferred = q.defer()
    // console.log("get det1")
    let url = config.url.getData
    postServiceCall('POST', url, payload)
      .then((result) => {
        log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'getData', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
        deferred.resolve(result)
      })
      .catch((error) => {
        log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'getData', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
        return deferred.reject(error)
      })
    return deferred.promise
  
  
}

module.exports.getData = getData
