/**
 * funcation is for calling service api to save Data
 * creating unqid and datetime to add into logger  
 */

 const uniqId = new Date().valueOf()
 const dateTime = new Date().toUTCString()
 let config = require('../config/config')
 let log = require('./loggerFunction').log
 let postServiceCall = require('./commmon')
 
 function nodeRFCCall(payload, cookie = '') {
   let deferred = q.defer()
   let url = config.url.noderfc
   postServiceCall.postServiceCall('POST', url, payload, cookie)
     .then((result) => {
       log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'nodeRFCCall', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
       deferred.resolve(result.result)
 
     })
     .catch((error) => {
       log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'nodeRFCCall', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
       return deferred.reject(error)
 
     })
   return deferred.promise
 
 }
 
 module.exports.nodeRFCCall = nodeRFCCall
 