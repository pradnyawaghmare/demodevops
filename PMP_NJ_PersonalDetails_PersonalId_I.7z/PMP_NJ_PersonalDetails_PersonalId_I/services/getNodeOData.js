/**
 * funcation is for calling service api to get data into oData
 * creating unqid and datetime to add into logger
 */

const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
const config = require('../config/config')
const log = require('./loggerFunction').log
const getServiceCall = require('./commmon').getServiceCall;

function getNodeOData (payload, cookie) {
  const deferred = q.defer()
  const url = config.url.getNodeOData + payload
  console.log('url-=-=-=->', url);
  getServiceCall('GET', url, cookie)
    .then((result) => {
      log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'getNodeOData', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
      deferred.resolve(result)
    })
    .catch((error) => {
      // console.log(error,',  ---error');
      log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'getNodeOData', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
      return deferred.reject({ message: error, code : 400 })
    })
  return deferred.promise
}

module.exports.getNodeOData = getNodeOData;
