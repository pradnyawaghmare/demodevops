/**
 * function is for calling service api to call store procedure service api
 * creating unqid and datetime to add into logger  
 */
const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
let config = require('../config/config')
let log = require('./loggerFunction').log
let postServiceCall = require('./commmon').postServiceCall

function executeSP(payload) {
    let deferred = q.defer()
  
    let url = config.url.StoreProcedure
    postServiceCall('POST', url, payload)
      .then((result) => {
        log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'callStoreProcedure', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
        deferred.resolve(result.result)
  
      })
      .catch((error) => {
        log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'callStoreProcedure', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
        return deferred.reject(error)
  
      })
    return deferred.promise
  
  }
  module.exports.executeSP = executeSP
  