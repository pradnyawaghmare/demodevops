const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
let postServiceCall = require('./commmon').postServiceCall
let config = require('../config/config')
  
  function mongoLog(platform, subplatform, bu, endpoint, uniqNo, application, componentType, step, remarks, inTime) {
      let payload = {
        "platform":platform,
        "subplatform":subplatform,
        "bu":bu,
        "endPoint": endpoint,
        "uniqId":uniqNo,
        "application":application,
        "componentType":componentType,
        "step":step,
        "remarks":remarks,
        "inTime":inTime
  }
      let deferred = q.defer()
      let url = config.url.mongoLogURL
      postServiceCall('POST', url, payload)
        .then((result) => {
          console.log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'mongoLog', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
    
        })
        .catch((error) => {
          console.log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'mongoLog', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
          return deferred.reject(error)
    
        })
      return deferred.promise
    
    }
module.exports.mongoLog = mongoLog

  