/**
 * function is for calling service api to read Data from redis using given key and DB of Redis
 * creating unqid and datetime to add into logger  
 */
const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
let config = require('../config/config')
let log = require('./loggerFunction').log
let postServiceCall = require('./commmon').postServiceCall

function readRedisData(payload) {
    let deferred = q.defer()
  
    let url = config.url.readRedisData
    postServiceCall('POST', url, payload)
      .then((result) => {
        log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'readRedisData', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
        deferred.resolve(result)
  
      })
      .catch((error) => {
        log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'readRedisData', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
        return deferred.reject(error)
  
      })
    return deferred.promise
  
  }
  module.exports.readRedisData = readRedisData
  