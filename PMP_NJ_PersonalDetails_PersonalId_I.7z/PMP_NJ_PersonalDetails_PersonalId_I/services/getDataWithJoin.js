/**
 * function is for calling service api to fetch Data
 * creating unqid and datetime to add into logger
 */
const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
const config = require('../config/config')
const log = require('./loggerFunction').log
const postServiceCall = require('./commmon').postServiceCall

function getDataWithJoin (payload) {
  const deferred = q.defer()
  // console.log("get det1")
  const url = config.url.getDataWithJoin
  postServiceCall('POST', url, payload)
    .then((result) => {
      log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'getDataWithJoin', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
      deferred.resolve(result)
    })
    .catch((error) => {
      log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'getDataWithJoin', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
      return deferred.reject(error)
    })
  return deferred.promise
}

module.exports.getDataWithJoin = getDataWithJoin
