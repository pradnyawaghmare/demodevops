/**
 * this function is common for  for calling request api
 * it take dynamicalliy method, url and payload to do request call
 */

const request = require('request');
const config = require('../config/config');
let stream = require('stream');
const _ = require('underscore');
const { Duplex } = stream;
const noderfcCall = require('../services/noderfcCall').nodeRFCCall

function postServiceCall(method, url, payload, cookie) {
	// console.log("get det2")
	let header = '';
	if (cookie) {
		header = {
			cookie         : cookie,
			'content-type' : 'application/json'
		};
	} else {
		header = {
			'content-type' : 'application/json'
		};
	}
	const deferred = q.defer();
	const options = {
		method    : method,
		url       : url,
		strictSSL : false,
		headers   : header,
		body      : payload,
		json      : true
	};

	console.log('options: ', options);
	request(options, function(error, response, body) {
		if (error) {
			return deferred.reject(error);
		} else {
			deferred.resolve(body);
		}
	});
	return deferred.promise;
}

function getServiceCall(method, url, cookie) {
	// console.log("get det2")
	const deferred = q.defer();
	const options = {
		method    : method,
		url       : url,
		strictSSL : false,
		headers   : {
			cookie         : cookie,
			'content-type' : 'application/json',
			Accept         : 'application/json'
		}
	};

	console.log('options: ', options);
	request(options, function(error, response, body) {
		if (error) {
			return deferred.reject(error);
		} else {
			body = JSON.parse(body);
			deferred.resolve({ body: body.result, statusCode: response.statusCode, message: body.message });
		}
	});
	return deferred.promise;
}

function addLogInAPM(unique_no, bu, inTime, step, remarks) {
	try {
		let apmLogData = {
			UniqueNo     : unique_no,
			BusinessUnit : bu,
			InTime       : inTime,
			step         : step,
			Remarks      : remarks
		};
		console.log('APM Log--------> ', apmLogData);
		apm.addLabels(apmLogData);
	} catch (error) {
		console.log('APM Error', error);
	}
}

async function callUploadToDMSAPI(fileDetails) {
	let deferred = q.defer();
	try {
		const originalname = fileDetails.originalname;
		const fileValues = originalname.split('.');
		console.log('fileValues  ===>', fileValues);
		let fileExtn = fileValues[fileValues.length - 1];

		let extensionWhiteList = config.utils.extension;
		let attachmentWhitelist = config.utils.mimeType;
		if (fileValues.length > 1) {
			if (attachmentWhitelist.indexOf(fileDetails.mimetype) === -1 && extensionWhiteList.indexOf(fileExtn) === -1) {
				deferred.reject('Upload image files only');
			} else {
				let fileStream = bufferToStream(fileDetails.buffer);
				console.log('URL', config.dms.upload_url);
				console.log('folder_ID', config.dms.folder_id);
				let options = {
					method    : 'POST',
					strictSSL : false,
					url       : config.dms.upload_url,
					headers   : {
						password : config.dms.pwd
					},
					formData  : {
						folder_id : config.dms.folder_id,
						file      : {
							value   : fileStream,
							options : {
								filename    : fileDetails.originalname,
								contentType : fileDetails.mimetype,
								knownLength : fileDetails.size
							}
						}
					}
				};
				request(options, function(error, response, body) {
					if (error) {
						console.log('error=>', error);
						deferred.reject({
							message : error,
							status  : false
						});
					} else {
						if (!_.isEmpty(body)) {
							let docInfo = JSON.parse(body);
							deferred.resolve(docInfo);
						} else {
							deferred.reject({
								message : docInfo,
								status  : false
							});
						}
					}
				});
			}
		} else {
			deferred.resolve('');
		}
	} catch (error) {
		console.log('error1=>', error);
		deferred.reject({
			message : error,
			status  : false
		});
	}
	return deferred.promise;
}

function bufferToStream(buffer) {
	const duplexStream = new Duplex();
	duplexStream.push(buffer);
	duplexStream.push(null);
	return duplexStream;
}
function returnTime() {
	const current = new Date();
	const inTime = current.toLocaleString();
	return inTime;
}
async function fileuploadCall(fileArr, cookie, businessUnit, uniqueNo, slug) {
	const deferred = q.defer()
	console.log("LOG ", fileArr.length)
	for (let i = 0; i < fileArr.length; i++) {
	  const fl = fileArr[i];
	  let files = {
		exception: true,
		fcode: businessUnit + '/F01',
		uniqueNo: uniqueNo,
		data: {
		  "IM_MODULE": "ZHR_ESS_PERSINFO",
		  "IM_SUBMODULE": "ATTACHMENTSET",
		  "IM_SLUG": `${fl.originalname}${slug}`,
		  "IM_MIMETYPE": fl.mimetype,
		  "IM_FILECONTENT": fl.buffer.toString('base64')
		}
	  }

	  await noderfcCall(files, cookie)
		.then((result) => {
		  console.log(fl.originalname+'---'+i);
		  deferred.resolve(result)
		}).catch(error => {
		  console.log(error, "noderfc error");
		  return deferred.reject(error)
		})
	}
	return deferred.promise
  }
module.exports.getServiceCall = getServiceCall
module.exports.postServiceCall = postServiceCall
module.exports.addLogInAPM = addLogInAPM;
module.exports.callUploadToDMSAPI = callUploadToDMSAPI
module.exports.returnTime = returnTime
module.exports.fileuploadCall = fileuploadCall