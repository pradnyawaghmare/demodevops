/**
 * function is for calling service api to produce Data into topic
 * creating unqid and datetime to add into logger  
 */

let config = require('../config/config')
let log = require('./loggerFunction').log
const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
let postServiceCall = require('./commmon').postServiceCall

function produceData(payload, cookie) {
    let deferred = q.defer()
  
    let url = config.url.produceData
    postServiceCall('POST', url, payload, cookie)
      .then((result) => {
        log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'produceData', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
        deferred.resolve(result)
  
      })
      .catch((error) => {
        log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'produceData', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
        return deferred.reject(error)
  
      })
    return deferred.promise
  
  }

  module.exports.produceData = produceData
