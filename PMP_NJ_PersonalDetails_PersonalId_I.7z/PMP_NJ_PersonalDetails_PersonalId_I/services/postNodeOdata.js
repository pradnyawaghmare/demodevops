/**
 * funcation is for calling service api to created data into oData
 * creating unqid and datetime to add into logger  
 */

const uniqId = new Date().valueOf()
const dateTime = new Date().toUTCString()
let config = require('../config/config')
let log = require('./loggerFunction').log
let postServiceCall = require('./commmon').postServiceCall
const moduleLogs = require('../model/MongoDBQuery/moduleLogs');
async function postNodeOData(payload, cookie) {
    let deferred = q.defer()
    let param = ""
    let saveMongoLog = { moduleCode: config.moduleCode, uniqueNo: payload.uniqueNo, payload: JSON.stringify(payload) };
    if (payload.queryparam)
      {
        param = payload.queryparam
        delete payload.queryparam
      }
    let url = config.url.postNodeOData + param
    let LogData = new moduleLogs(saveMongoLog);

    await LogData.save((err, value) => {
      if (err) {
        console.log('Error while saving mongologs in mongodb : ', err);
      } else {
        console.log('mongologs saved successfully in mongo db');
      }
    });
    postServiceCall('POST', url, payload, cookie)
      .then((result) => {
        log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'postNodeOData', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(result), error: '', warning: '' })
        deferred.resolve(result)
  
      })
      .catch((error) => {
        log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'postNodeOData', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(error), warning: '' })
        return deferred.reject(error)
  
      })
    return deferred.promise
  
}
function fileUploadOdata(payload, cookie) {
    let deferred = q.defer()
    let urlfile = config.url.fileUploadOData
    postServiceCall('POST', urlfile, payload, cookie)
      .then((resultfile) => {
        log({ uniqueInfo: uniqId, stepNo: '1.1', function: 'fileUploadOdata', dateTime: dateTime, text: 'text', dataInf: JSON.stringify(resultfile), error: '', warning: '' })
        deferred.resolve(resultfile)
      })
      .catch((errorfile) => {
        log({ uniqueInfo: uniqId, stepNo: '1.2', function: 'fileUploadOdata', dateTime: dateTime, text: 'text', dataInf: '', error: JSON.stringify(errorfile), warning: '' })
        return deferred.reject(errorfile)
  
      })
    return deferred.promise
  }
  
  module.exports.fileUploadOdata = fileUploadOdata
  module.exports.postNodeOData = postNodeOData
