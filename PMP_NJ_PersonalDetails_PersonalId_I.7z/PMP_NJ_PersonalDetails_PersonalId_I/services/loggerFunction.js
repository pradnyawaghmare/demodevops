let config = require('../config/config')


function loggerFunction (data) {
  let logData = {}
  logData.uniqueInfo = data.uniqueInfo
  logData.stepNo = data.stepNo
  logData.function = data.function
  logData.dateTime = data.dateTime
  if (config.loggerData && Object.keys(config.loggerData).length) {
    if (config.loggerData.Information == 'Y') {
      logData.text = data.text
      logData.dataInf = data.dataInf
    }
    if (config.loggerData.Warning == 'Y') {
      logData.warning = data.warning
    }
    if (config.loggerData.Error == 'Y') {
      logData.error = data.error
    }
  } else {
    logData = data
  }
  if (config.LOGGER === true) {
    console.log(logData)
  }
}

module.exports.log = loggerFunction