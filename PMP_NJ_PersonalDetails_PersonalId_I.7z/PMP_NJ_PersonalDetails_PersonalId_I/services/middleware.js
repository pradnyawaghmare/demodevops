const uniqId = new Date().valueOf();
const dateTime = new Date().toUTCString();
let log = require('../services/loggerFunction').log;

const postServiceCall = require('./commmon').postServiceCall;
let config = require('../config/config')

function validateCookie(req, res, next) {
	//
	const deferred = q.defer();
	const endpointName = req.url.split('/')[3];
	let mysapsso2Value;
	if (config.validateMYSAPSSO2[endpointName] == undefined) {
		mysapsso2Value = false;
	} else {
		mysapsso2Value = config.validateMYSAPSSO2[endpointName];
	}

	let payload = { checkMysso: true, checkMysapsso2: mysapsso2Value };

	postServiceCall('POST', config.url.checkCookies, payload, req.headers.cookie)
		.then((result) => {
			log({
				uniqueInfo: uniqId,
				stepNo: '0',
				function: 'checkCookies',
				dateTime: dateTime,
				text: 'text',
				dataInf: result,
				error: '',
				warning: ''
			});

			if (payload.checkMysapsso2 && payload.checkMysso) {
				if (cookieStatus(req, result.result.MYSSO, 'MYSSO', result.result.data) && cookieStatus(req, result.result.MYSAPSSO2, 'MYSAPSSO2')) {
					deferred.resolve(true);
				} else {
					httpResponseHandlerError(res, msgCodeJson.ERR003.code, 'Invalid Cookies');
				}
			} else if (payload.checkMysso) {
				if (cookieStatus(req, result.result.MYSSO, 'MYSSO', result.result.data)) {
					deferred.resolve(true);
					//   return result
				} else {
					httpResponseHandlerError(res, msgCodeJson.ERR003.code, 'Invalid Cookies');
				}
			} else if (payload.checkMysapsso2) {
				if (cookieStatus(req, result.result.MYSAPSSO2, 'MYSAPSSO2')) {
					deferred.resolve(true);
				} else {
					httpResponseHandlerError(res, msgCodeJson.ERR003.code, 'Invalid Cookies');
				}
			} else {
				httpResponseHandlerError(res, msgCodeJson.ERR003.code, 'Invalid Cookies');
			}
		})
		.catch((error) => {
			log({
				uniqueInfo: uniqId,
				stepNo: '0',
				function: 'checkCookies',
				dateTime: dateTime,
				text: 'text',
				dataInf: '',
				error: JSON.stringify(error),
				warning: ''
			});
			httpResponseHandlerError(res, msgCodeJson.ERR003.code, 'Invalid Cookies');
		});
	return deferred.promise;
}

function cookieStatus(req, status, whichCookie, data = '') {
	if (status) {
		req[whichCookie] = status;
		if (whichCookie === 'MYSSO') req.info = data;
		return true;
	} else {
		return false;
	}
}

function filecheck(req, res, next) {
	let attachmentWhitelist = config.utils.mimeType.split(';');
	let file = req.files && req.files.length ? req.files : [];

	if (file.length > 0) {
		if (file.filter((x) => x.size > 2097152 || !attachmentWhitelist.includes(x.mimetype)).length == 0) next();
		else httpResponseHandlerError(res, msgCodeJson.ERR008.code, 'Attachment size too large/ type invalid');
	} else next();
}

function checkBody(payload) {
	let notAllowedArr = config.notAllowedArr
	notAllowedArr.push('&&')
	console.log("notAllowedArr ",notAllowedArr)
	let result = notAllowedArr.some((i) => payload.includes(i));
	console.log('payload body/query', payload, 'result ===>', result);
	return result;
}

function validateReq(req, res, next) {
	let checkBodyResult;
	let isValidPayload = true;
	let checkResultArr = [];
	// const deferred = q.defer();
	if (Object.keys(req.query).length) {
		checkBodyResult = checkBody(JSON.stringify(req.query));
		checkResultArr.push(checkBodyResult);
	}
	if (Object.keys(req.body).length) {
		checkBodyResult = checkBody(JSON.stringify(req.body));
		checkResultArr.push(checkBodyResult);
	}
	if (checkResultArr.length && checkResultArr.includes(true)) isValidPayload = false;

	if (isValidPayload) {
		next();
		// deferred.resolve(true);
	} else {
		httpResponseHandlerError(
			res,
			msgCodeJson.ERR008.code,
			`Invalid request parameters, body should not include any special character '&&', '|', '||', '$(', '<', '>', '>>', '--'`
		);
	}

	// return deferred.promise;
}

module.exports.validateCookie = validateCookie;
module.exports.filecheck = filecheck;
module.exports.validateReq = validateReq;
