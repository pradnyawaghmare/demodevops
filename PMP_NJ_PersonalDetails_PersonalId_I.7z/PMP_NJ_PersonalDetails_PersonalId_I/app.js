const express = require('express');
const path = require('path');
const indexRouter = require('./routes/index');
const config = require('./config/config');
const getUrlPrefix = config.app.prefix;

// MongoDb Connection 
require('./utils/MongoDB/mongo')

const app = express();
// APM
const apmInput = require('./utils/KIBANA/APM/apm');

function startAPM() {
	let apmFlag = true;
	try {
		global.apm = require('elastic-apm-node').start(apmInput);
	} catch (error) {
		apmFlag = false;
		console.log('APM Is Not Available', error);
	}

	return apmFlag;
}

function apmCall() {
	if (startAPM() === true) {
		console.log('APM is Running');
	} else {
		console.log('APM is Trying To ReConnect');
		/* APM will reconnect after 1 Hr */
		setTimeout(function() {
			apmCall();
		}, 3600000);
	}
}
apmCall();

/* GLOBAL VARIABLES */
global.q = require('q');
global.config = require('./config/config');
global._ = require('underscore');
global.log = require('./services/loggerFunction').log;
global.msgCodeJson = require('./utils/MsgCode/msgCode');
global.httpResponseHandlerError = require('./services/httpResponseHandler').httpResponseHandlerError;
global.httpResponseSuccessHandler = require('./services/httpResponseHandler').httpResponseSuccessHandler;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);

// error handler
app.use(function(err, req, res, next) {
	// set locals, only providing error in development
	res.locals.message = err.message;
	res.locals.error = req.app.get('env') === 'development' ? err : {};
	// render the error page
	res.status(err.status || 500);
});

/* SERVER START */
const port = process.env.PORT || config.server.port;
const server = app.listen(port);
console.log('Api is running on port', port);
console.log(`try this url http://localhost:${port}${getUrlPrefix}/ping`);

module.exports = app;
