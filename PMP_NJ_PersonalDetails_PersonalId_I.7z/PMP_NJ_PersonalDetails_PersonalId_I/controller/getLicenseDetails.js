
const getNodeOData = require('../services/getNodeOData').getNodeOData
const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
const {addLogInAPM, returnTime} = require('../services/commmon')

async function getLicenseDetails(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf()
  const uniqueNo = config.moduleCode + uniqId
  const inTime = returnTime()
  const LDfcode = 'F04'
  const BU = req.info.business_unit
  const skip = 0
  const top = 100
  const inLineCount = 'allpages'
  const apiUrl = `fcode=${BU}/${LDfcode}&param=?$skip=${skip}&$top=${top}&$inlinecount=${inLineCount}`
  console.log('getLicenseDetails apiUrl', apiUrl)
  getNodeOData(apiUrl, cookie, uniqueNo)
    .then((LDresult) => {
        console.log("getLicenseDetails odata result ",LDresult)
      if (_.has(LDresult, 'body') && LDresult.body.d && LDresult.body.d.results) {
        const output = returnFormateOut(LDresult.body.d.results)
        logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, BU + '/' + LDfcode, 'getLicenseDetails - ' + '15', uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
        addLogInAPM(uniqueNo, LDfcode, inTime, 1, 'Interface Calling')
        httpResponseSuccessHandler(res, LDresult.statusCode, LDresult.message, output)
      } else {
        httpResponseHandlerError(res, msgCodeJson.ERR002.code, msgCodeJson.ERR002.msg)
      }
    })
    .catch((LDerror) => {
      httpResponseHandlerError(res, LDerror.code, LDerror.message)
    })
}

function returnFormateOut (result) {
    let outPutResult = []
    if(result.length>0){
        result.forEach((rec)=>{
            let val = {}
            val.user = rec.ImUser
            val.licenseType = rec.Ictyp
            val.licenseTypeText = rec.Ictxt
            val.licenseNumber = rec.Icnum
            val.issueAuthority = rec.Auth1
            val.issueDate = parseInt(rec.Fpdat.slice(rec.Fpdat.indexOf('(')+1,rec.Fpdat.indexOf(')')))
            val.expiryDate = parseInt(rec.Expid.slice(rec.Expid.indexOf('(')+1,rec.Expid.indexOf(')')))
            val.issuePlace = rec.Isspl
            val.countryCode = rec.Iscot
            val.countryName = rec.coountry_text
            outPutResult.push(val)
        })
    }
    return outPutResult
  }

module.exports.getLicenseDetails = getLicenseDetails
