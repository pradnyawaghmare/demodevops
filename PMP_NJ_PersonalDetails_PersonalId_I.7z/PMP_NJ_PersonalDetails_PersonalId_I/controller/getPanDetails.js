const getNodeOData = require('../services/getNodeOData').getNodeOData;
const apmDetails = require('../utils/KIBANA/APM/apm');
const logs = require('../services/mongoLogger').mongoLog;
const addLogInAPM = require('../services/commmon').addLogInAPM;
const rTime = require('../services/commmon');

async function getPanDetails(req, res) {
	const cookie = req.headers.cookie;
	const uniqId = new Date().valueOf();
	const uniqueNo = config.moduleCode + uniqId;
	const inTime = rTime.returnTime();
	const pdfcode = 'F03';
	const BU = req.info.business_unit;
	const apiUrl = `fcode=${BU}/${pdfcode}`;
	console.log('apiUrl', apiUrl);
	getNodeOData(apiUrl, cookie)
		.then((pdresult) => {
			console.log('pan detail odata log', pdresult);
			if (pdresult.body && pdresult.body.d) {
				const output = returnFormateOut(pdresult.body.d);
				logs(
					apmDetails.globalLabels.platform,
					apmDetails.globalLabels.sub_platform,
					BU + '/' + pdfcode,
					'getPanDetails - ' + '15',
					uniqueNo,
					apmDetails.globalLabels.application,
					apmDetails.globalLabels.component_type,
					1,
					'Interface Calling',
					inTime
				);
				addLogInAPM(uniqueNo, pdfcode, inTime, 1, 'Interface Calling');
				httpResponseSuccessHandler(res, pdresult.statusCode, pdresult.message, output);
			} else {
				httpResponseHandlerError(res, msgCodeJson.ERR002.code, msgCodeJson.ERR002.msg);
			}
		})
		.catch((pderror) => {
			console.log(pderror);
			httpResponseHandlerError(res, pderror.code, pderror.message);
		});
}

function returnFormateOut(obj) {
	let outPutResult = {};

	outPutResult.user = obj.ImUser;
	outPutResult.newPAN = obj.Newpan;
	outPutResult.subType = obj.Subty;
	outPutResult.idNumber = obj.Idnum;
	outPutResult.panNumber = obj.Pannum;
	outPutResult.remarks = obj.Remarks;
	outPutResult.flag = obj.Flag;
	outPutResult.uidNumber = obj.Uid;
	outPutResult.voterId = obj.Voterid;
	outPutResult.uanNumber = obj.Uan;
	outPutResult.exFlag = obj.ExFlag;
	outPutResult.exVerify = obj.ExVerify;
	outPutResult.exPrint = obj.ExPrint;
	outPutResult.startText = obj.StatText;

	return outPutResult;
}

module.exports.getPanDetails = getPanDetails;
