const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
let { postNodeOData,fileUploadOdata } = require('../services/postNodeOdata')
const { callUploadToDMSAPI,addLogInAPM,fileuploadCall } = require('../services/commmon')
const moduleVaults = require('../model/MongoDBQuery/moduleVault')

async function saveVisaDetails(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf();
  const uniqueNo = config.moduleCode + uniqId
  const inTime = new Date().toLocaleString()
  const BU = req.info.business_unit
  const file = req.files && req.files.length ? req.files : []
  const body = JSON.parse(req.body.jsonstring)
  const delVD = req.body.deleteAttachmentList && req.body.deleteAttachmentList.length>0?req.body.deleteAttachmentList.split(","):[]
  const VDFcode = `${BU}/${'F65'}`
  const VDASFcode = `${BU}/${'F26'}`
  const issueDate = parseInt(body.issueDate) + 19800000
  const expiryDate = parseInt(body.expiryDate) + 19800000

  let VDinputPayload = {
      "fcode": VDFcode,
      "data": {
        "Docn2": body.idNumber,
        "Auth2": body.issuingAuthority,
        "Date2": "\/Date("+issueDate+")\/",
        "Expdt": "\/Date("+expiryDate+")\/",
        "Cvnum": body.caseVerificationNumber
      },
     "uniqueNo": uniqueNo
  }

  console.log('saveVisaDetails=======>', VDinputPayload, VDFcode)
  let saveVaultData = { "uniqueNo": uniqueNo, "cookie": cookie, "module": config.moduleCode }
  const VDvaultData = new moduleVaults(saveVaultData)
  await VDvaultData.save((VDerr, value) => {
    if (VDerr) {
      console.log("Error while saving vaultData in mongodb : ", VDerr)
    } else {
      console.log("vaultData saved successfully in mongo db")
    }
  })
  if (file && file.length > 0) {
    let VDASfileData = await fileuploadCall(file, cookie, BU, uniqueNo,"@R_VISA")
    if (VDASfileData && VDASfileData.EX_PAYLOAD && VDASfileData.EX_PAYLOAD.ET_RETURN && VDASfileData.EX_PAYLOAD_JSON.ET_RETURN.length && VDASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].TYPE != "S") {
      console.log("Error in updating attachment ", VDASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE);
      // return httpResponseHandlerError(res, 400, filesave.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE)
    }
    else{
      console.log("Attachment successfully Created")
    }
    // const VDASfileData = await callUploadToDMSAPI(file);
    // if (VDASfileData.OPStatus.StatusType === 'S') {
    //   let VDASpayload = {
    //     "fcode": VDASFcode,
    //     "headers":{
    //       "slug":VDASfileData.data.originalname+"@R_VISA",
    //       "Content-Type": req.file.mimetype,
    //       "content-transfer-encoding": 'Base64'
    //     },
    //     "data":{
    //       "content": req.file.buffer.toString('base64'),
    //     },
    //     "uniqueNo": uniqueNo
    //   }
    //   fileUploadOdata(VDASpayload, cookie)
    //     .then((VDASresult) => {
    //       console.log("Attachment successfully ",VDASresult.message)  
    //     })
    //     .catch((VDASerror) => {
    //       console.log("Error in updating attachment ",VDASerror)      
    //     })
    //   console.log("Uploaded to DMS")
    // }
  }
  if(delVD.length>0){
    delVD.forEach((delrecVD)=>{
      let VDALSFcode = `${BU}/${'F45'}`
      let VDALSinputPayload = {
        "method":"DELETE",
        "queryparam":"?param=(Docid='"+delrecVD+"',Fieldname='R_VISA')",
        "fcode": VDALSFcode,
        "uniqueNo": uniqueNo
      }
      postNodeOData(VDALSinputPayload, cookie)
        .then((VDALSresult) => {
          console.log("Attachment successfully ",VDALSresult)  
        })
        .catch((VDALSerror) => {
          console.log("Error in deleting attachment ",VDALSerror)      
        })
    })
  }
  postNodeOData(VDinputPayload, cookie)
    .then((VDresult) => {
      let output = {}
      if(VDresult && VDresult.code && VDresult.code != 302)
        VDresult = JSON.parse(VDresult.message)
      if(VDresult && VDresult.error)
        output = {systemErrMsg:VDresult.error.message.value,responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      else
        output = {responseErrMsg:"",responseStatus:"SUCCESS"}
      logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, VDFcode,"saveVisaDetails - " + "15", uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
      addLogInAPM(uniqueNo, VDFcode, inTime, 1, "saveVisaDetails - " + "15 - "+"Interface Calling")
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, output)
    })
    .catch((VDerror) => {
      console.log(VDerror)
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

module.exports.saveVisaDetails = saveVisaDetails
