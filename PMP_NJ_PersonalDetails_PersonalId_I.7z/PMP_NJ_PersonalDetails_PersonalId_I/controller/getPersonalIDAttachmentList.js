
const getNodeOData = require('../services/getNodeOData').getNodeOData
const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
const addLogInAPM = require('../services/commmon').addLogInAPM
const common = require('../services/commmon')
async function getPersonalIDAttachmentList(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf()
  const uniqueNo = config.moduleCode + uniqId
  const inTime = common.returnTime()
  const fcode = "F35";
  const BU = req.info.business_unit
  const type = req.query.type
  const param = {"AADHAAR" : 'R_UID' , "PAN":"R_PAN","VOTER":"R_VID","VISA":"R_VISA","PASSPORT":"R_PASSPORT","DRIVING_LICENSE":"R_DRV06"}
  if(!type || !param.hasOwnProperty(type)){
    res.status(404)
    res.end("Param is null or not defined , please send correct param")
  }
  const apiUrl = `fcode=${BU}/${fcode}&param=?$filter=Fieldname eq '${param[type]}'`;
  console.log('getPersonalIDAttachmentList apiUrl', apiUrl)
  getNodeOData(apiUrl, cookie, uniqueNo)
    .then((aadharResult) => {
      if ( aadharResult.body && aadharResult.body.d && aadharResult.body.d.results) {
        const aadharOutput = returnFormateOuPersonalIDDetails(aadharResult.body.d.results)
        logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, BU + '/' + fcode, 'getPersonalIDAttachmentList - ' + '15', uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
        addLogInAPM(uniqueNo, fcode, inTime, 1, 'Interface Calling')
        httpResponseSuccessHandler(res, aadharResult.statusCode, aadharResult.message, aadharOutput)
      } 
      else if (aadharResult.error) {

				console.log("getPersonalIDAttachmentList Error 2====> ", aadharResult)
				return res.status(400).send({ systemErrMsg: aadharResult.error.message.value, responseErrMsg: "Sorry for the inconvenience.", responseStatus: "FAILED" })

			}
			else {

				console.log("getPersonalIDAttachmentList Error 3====>", aadharResult)
				return res.status(400).send({ responseErrMsg: "Some Error Occured in getPersonalIDAttachmentList ", responseStatus: "FAILED" })

			}
		})
		.catch((error) => {
			console.log("getPersonalIDAttachmentList Error", error)
			res.status(500).send({ responseErrMsg: "Internal Server for getPersonalIDAttachmentList ", responseStatus: "FAILED" })
		});
}

function returnFormateOuPersonalIDDetails(personalIDObj) {
    let outputPersonalID = [];
    for(let obj of personalIDObj){
      let t = {
        fileName : obj.Filename,
        documentId : obj.Docid,
        oldDocumentFlag : obj.OldDoc == "X" ? true : false
      }
      outputPersonalID.push(t)
    }

	return outputPersonalID
}

module.exports.getPersonalIDAttachmentList = getPersonalIDAttachmentList
