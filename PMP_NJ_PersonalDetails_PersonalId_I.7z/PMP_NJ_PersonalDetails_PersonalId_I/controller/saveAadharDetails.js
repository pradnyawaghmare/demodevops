const apmDetails = require('../utils/KIBANA/APM/apm');
const logs = require('../services/mongoLogger').mongoLog;
let postNodeOData = require('../services/postNodeOdata').postNodeOData;
var {callUploadToDMSAPI,addLogInAPM,fileuploadCall} = require('../services/commmon');
const moduleVaults = require('../model/MongoDBQuery/moduleVault');
async function saveAadharDetails(req, res) {
  const cookie = req.headers.cookie;
  const uniqId = new Date().valueOf();
  const uniqueNo = config.moduleCode + uniqId;
  const inTime = new Date().toLocaleString();
  const BU = req.info.business_unit;
  const file = req.files && req.files.length ? req.files : []
  const body = JSON.parse(req.body.jsonstring);
  const SAFcode = `${BU}/${'F59'}`;
  const ATTFcode = `${BU}/${'F26'}`;
  const deleteAttachments = req.body.deleteAttachmentList && req.body.deleteAttachmentList.length>0?req.body.deleteAttachmentList.split(","):[]
  const birthdate = parseInt(body.dateOfBirth) + 19800000
  // const SAFcode = `${BU}/${'F59'}`
  // const ATTFcode = `${BU}/${'F26'}`
  input_obj = {
      "fcode": SAFcode,
      "data": {
        "UidNo":body.aadhaarNumber,
        "UidName":body.aadhaarName,
        "Gender":body.gender.toLowerCase() == "male" ? "1" : "2",
        "DOB":"\/Date("+birthdate+")\/",
        "Action":body.action
     },
     "uniqueNo": uniqueNo
  }
  var sap_val = { "uniqueNo": uniqueNo, "cookie": cookie, "module": config.moduleCode }
  const val_save_fn = new moduleVaults(sap_val)
  await val_save_fn.save((err, value) => {
    if (err) {
      console.log("Error while saving vaultData in mongodb : ", err)
    } else {
      console.log("vaultData saved successfully in mongo db")
    }
  });
  if (file && file.length > 0) {
    let fileData = await fileuploadCall(file, cookie, BU, uniqueNo,"@R_UID")
    if (fileData && fileData.EX_PAYLOAD && fileData.EX_PAYLOAD.ET_RETURN && fileData.EX_PAYLOAD_JSON.ET_RETURN.length && fileData.EX_PAYLOAD_JSON.ET_RETURN[0].TYPE != "S") {
      console.log("Error in updating attachment ", fileData.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE);
      // return httpResponseHandlerError(res, 400, filesave.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE)
    }
    else{
      console.log("Attachment successfully Created")
    }
    // const fileData = await callUploadToDMSAPI(file);
    // if (fileData.OPStatus.StatusType === 'S') {
    //   let payload = {
    //     "fcode": ATTFcode,
    //     "headers":{
    //       "slug":fileData.data.filename+"@INF21"
    //     },
    //     "uniqueNo": uniqueNo
    //   }
    //   postNodeOData(payload, cookie)
    //     .then((atresult) => {
    //       console.log("Attachment successfully ",atresult.message)  
    //     })
    //     .catch((aterror) => {
    //       console.log("Error in updating attachment ",aterror)      
    //     })
    //   console.log("Uploaded to DMS")
    // }
  }
  if(deleteAttachments.length > 0) {
    deleteAttachments.forEach((delrec)=>{
      let DALSFcode = `${BU}/${'F45'}`
      let ALSinputPayload = {
        "method":"DELETE",
        "queryparam":"?param=(Docid='"+delrec+"',Fieldname='R_UID')",
        "fcode": DALSFcode,
        "uniqueNo": uniqueNo
      }
      postNodeOData(ALSinputPayload, cookie)
        .then((ALSresult) => {
          console.log("Attachment successfully ",ALSresult);
          console.log('I am here in');
        })
        .catch((ALSerror) => {
          console.log("Error in deleting attachment ",ALSerror)      
        })
    })
  }
  postNodeOData(input_obj, cookie).then((SDresult) => {
      // console.log("Result ",SDresult)
      let output = {}
      if(SDresult && SDresult.message != "" && SDresult.message != "Created")
        SDresult = JSON.parse(SDresult.message)
      if(SDresult && SDresult.error)
      	output = {systemErrMsg:SDresult.error.message.value,responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      else if(SDresult && SDresult.result)
        output = {responseData:JSON.stringify(SDresult.result),responseErrMsg:"",responseStatus:"SUCCESS"}
      else
        output = {systemErrMsg:"Unhandled error from SAP",responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      // let output = {responseData:JSON.stringify(SDresult.result),responseErrMsg:"",responseStatus:"SUCCESS"}
      // logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, SAFcode,"save Aadhar Details - " + "15", uniqueNo,         apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
      // addLogInAPM(uniqueNo, SAFcode, inTime, 1, "save Aadhar Details - " + "15 - "+"Interface Calling")
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, output)
  }).catch((SDerror) => {
    console.log(SDerror)
    httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
  });
}

module.exports.saveAadharDetails = saveAadharDetails
