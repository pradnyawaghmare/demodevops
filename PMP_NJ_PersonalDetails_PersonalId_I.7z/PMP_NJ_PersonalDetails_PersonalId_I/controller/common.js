async function getStreamOut(result) {
	const deferred = q.defer();
	try {
		let buffers = [];
		await result.on('data', function(chunk) {
			buffers.push(chunk);
		});
		await result.on('end', function() {
			let pdfData = Buffer.concat(buffers);
			try {
				let jsonValue = JSON.parse(pdfData.toString());
				if (jsonValue && jsonValue.error && jsonValue.error.message) {
					deferred.reject(jsonValue.error.message);
				} else {
					console.log(pdfData, '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>..');

					deferred.resolve(pdfData);
				}
			} catch (error) {
				deferred.resolve(pdfData);
			}
		});
		await result.on('error', function(err) {
			console.log(err.stack);
			deferred.reject({
				value : 'Error While retriving document'
			});
		});
	} catch (error) {
		console.log('error', error);
		deferred.reject(error);
	}
	return deferred.promise;
}

module.exports.getStreamOut = getStreamOut;
