
const getNodeOData = require('../services/getNodeOData').getNodeOData
const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
const {addLogInAPM, returnTime} = require('../services/commmon')

async function getDrivingLicensetypes(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf()
  const uniqueNo = config.moduleCode + uniqId
  const inTime = returnTime()
  const dltFcode = 'F71'
  const BU = req.info.business_unit
  const apiUrl = `fcode=${BU}/${dltFcode}`
  console.log('getDrivingLicensetypes apiUrl', apiUrl)
  getNodeOData(apiUrl, cookie, uniqueNo)
    .then((drivingLicensetypesResult) => {
      if (drivingLicensetypesResult.body && drivingLicensetypesResult.body.d && drivingLicensetypesResult.body.d.results) {
        const output = returnFormateOut(drivingLicensetypesResult.body.d.results)
        logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, BU + '/' + dltFcode, 'getDrivingLicensetypes - ' + '15', uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
        addLogInAPM(uniqueNo, dltFcode, inTime, 1, 'Interface Calling')
        httpResponseSuccessHandler(res, drivingLicensetypesResult.statusCode, drivingLicensetypesResult.message, output)
      } else if (drivingLicensetypesResult.error) {

        console.log("getDrivingLicensetypes Error 2====> ", drivingLicensetypesResult)
        return res.status(400).send({ systemErrMsg: drivingLicensetypesResult.error.message.value, responseErrMsg: "Sorry for the inconvenience.", responseStatus: "FAILED" })

    }
    else {

        console.log("getDrivingLicensetypes Error 3====>", drivingLicensetypesResult)
        return res.status(400).send({ responseErrMsg: "Some Error Occured in getDrivingLicensetypes ", responseStatus: "FAILED" })

    }
})
.catch((error) => {
    console.log("getDrivingLicensetypes Error", error)
    res.status(500).send({ responseErrMsg: "Internal Server for getDrivingLicensetypes ", responseStatus: "FAILED" })
});
}

function returnFormateOut (dlObj) {
    let dlResult = []
    for(let dobj of dlObj){
        let t = {
            key : dobj.Ictyp,
            value : dobj.Ictxt
        }
        dlResult.push(t)
    }
    return dlResult
  }

module.exports.getDrivingLicensetypes = getDrivingLicensetypes
