/**
 * this function is wrapper for calling noderfc service api 
 */

const nodeRFCCall = require('../services/noderfcCall').nodeRFCCall

function noderfc(req, res) {
  const inputPayload = req.body
  nodeRFCCall(inputPayload)
    .then((result) => {
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, result)
    })
    .catch((error) => {
      console.log(error)
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

module.exports.noderfc = noderfc
