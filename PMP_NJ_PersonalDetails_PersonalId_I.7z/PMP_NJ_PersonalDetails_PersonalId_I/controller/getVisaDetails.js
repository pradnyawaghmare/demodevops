
const getNodeOData = require('../services/getNodeOData').getNodeOData
const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
const {addLogInAPM, returnTime} = require('../services/commmon')

async function getVisaDetails(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf()
  const uniqueNo = config.moduleCode + uniqId
  const inTime = returnTime()
  const VDfcode = 'F15'
  const BU = req.info.business_unit
  const apiUrl = `fcode=${BU}/${VDfcode}`
  console.log('getVisaDetails apiUrl', apiUrl)
  getNodeOData(apiUrl, cookie, uniqueNo)
    .then((VDresult) => {
        console.log("getVisaDetails odata results ",VDresult)
      if (_.has(VDresult, 'body') && VDresult.body.d) {
        const output = returnFormateOut(VDresult.body.d)
        logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, BU + '/' + VDfcode, 'getVisaDetails - ' + '15', uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
        addLogInAPM(uniqueNo, VDfcode, inTime, 1, 'Interface Calling')
        httpResponseSuccessHandler(res, VDresult.statusCode, VDresult.message, output)
      } else {
        httpResponseHandlerError(res, msgCodeJson.ERR002.code, msgCodeJson.ERR002.msg)
      }
    })
    .catch((VDerror) => {
      httpResponseHandlerError(res, VDerror.code, VDerror.message)
    })
}

function returnFormateOut (result) {
    let outPutResult = {}
    outPutResult.user = result.ImUser
    outPutResult.idNumber = result.Docn2
    let issueDate = result.Date2 ? parseInt(result.Date2.slice(result.Date2.indexOf('(')+1,result.Date2.indexOf(')'))) + 19800000 : result.Date2;
    // issueDate = issueDate + 19800000; 
    let expiryDate = result.Expdt ? parseInt(result.Expdt.slice(result.Expdt.indexOf('(')+1,result.Expdt.indexOf(')'))) + 19800000 : result.Expdt;
    // expiryDate = expiryDate + 19800000; 
    
    outPutResult.issueDate = issueDate
    outPutResult.expiryDate = expiryDate
    outPutResult.issuingAuthority = result.Auth2
    outPutResult.caseVerificationNumber = result.Cvnum

    return outPutResult
  }

module.exports.getVisaDetails = getVisaDetails
