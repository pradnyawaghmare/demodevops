/**
 * this function is wrapper for calling create odata service api to create data
 */

let postNodeOData = require('../services/postNodeOdata').postNodeOData
function saveNodeOData(req, res){
    let inputPayload = req.body
    let cookie = req.headers.cookie
    postNodeOData(inputPayload, cookie)
    .then((result) => {
        httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, result)
      })
      .catch((error) => {
        httpResponseHandlerError(res, msgCodeJson.ERR008.code, error)
      })
}

module.exports.saveNodeOData = saveNodeOData