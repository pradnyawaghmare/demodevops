const getNodeOData = require('../services/getNodeOData').getNodeOData;
const apmDetails = require('../utils/KIBANA/APM/apm');
const logs = require('../services/mongoLogger').mongoLog;
const addLogInAPM = require('../services/commmon').addLogInAPM;
const rTime = require('../services/commmon');

async function getAdharDetails(req, res) {
	const cookie = req.headers.cookie;
	const uniqId = new Date().valueOf();
	const uniqueNo = config.moduleCode + uniqId;
	const inTime = rTime.returnTime();
	const adfcode = 'F01';
	const BU = req.info.business_unit;

	const apiUrl = `fcode=${BU}/${adfcode}`;
	console.log('apiUrl', apiUrl);
	getNodeOData(apiUrl, cookie)
		.then((adresult) => {
			console.log('adhar details odata log', adresult);
			if (adresult.body && adresult.body.d) {
				const output = returnFormateOut(adresult.body.d);
				logs(
					apmDetails.globalLabels.platform,
					apmDetails.globalLabels.sub_platform,
					BU + '/' + adfcode,
					'getAdharDetails - ' + '15',
					uniqueNo,
					apmDetails.globalLabels.application,
					apmDetails.globalLabels.component_type,
					1,
					'Interface Calling',
					inTime
				);
				addLogInAPM(uniqueNo, adfcode, inTime, 1, 'Interface Calling');
				httpResponseSuccessHandler(res, adresult.statusCode, adresult.message, output);
			} else {
				httpResponseHandlerError(res, msgCodeJson.ERR002.code, msgCodeJson.ERR002.msg);
			}
		})
		.catch((aderror) => {
			console.log(aderror);
			httpResponseHandlerError(res, aderror.code, aderror.message);
		});
}

function returnFormateOut(obj) {
	let outPutResult = {};
	// let birthdate = parseInt(obj.DOB.slice(obj.DOB.indexOf('(') + 1, obj.DOB.indexOf(')')));
	birthdate = obj.DOB ? parseInt(obj.DOB.slice(obj.DOB.indexOf('(') + 1, obj.DOB.indexOf(')'))) + 19800000 : obj.DOB; //> 0 ? birthdate + 19800000 : birthdate + 19800000
	outPutResult.uniqueIdNo = obj.UidNo;
	outPutResult.uniqueIdName = obj.UidName;
	outPutResult.gender = obj.Gender;
	outPutResult.genderText = obj.GenderText;
	outPutResult.dateOfBirth = birthdate;
	outPutResult.nameFlag = obj.NameFlg;
	outPutResult.dateOfBirthFlag = obj.DOBFlg;
	outPutResult.genderFlag = obj.GenderFlg;
	outPutResult.action = obj.Action;
	outPutResult.hyperlink = obj.Hyperlink;
	outPutResult.notEdit = obj.NotEdit;

	return outPutResult;
}

module.exports.getAdharDetails = getAdharDetails;
