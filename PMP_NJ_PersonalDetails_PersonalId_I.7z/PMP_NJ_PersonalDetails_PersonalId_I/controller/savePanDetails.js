const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
let postNodeOData = require('../services/postNodeOdata').postNodeOData
const { callUploadToDMSAPI,addLogInAPM,fileuploadCall } = require('../services/commmon')
const moduleVaults = require('../model/MongoDBQuery/moduleVault')

async function savePanDetails(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf();
  const uniqueNo = config.moduleCode + uniqId
  const inTime = new Date().toLocaleString()
  const BU = req.info.business_unit
  const file = req.files && req.files.length ? req.files : []
  const body = JSON.parse(req.body.jsonstring)
  const delatt = req.body.deleteAttachmentList && req.body.deleteAttachmentList.length>0?req.body.deleteAttachmentList.split(","):[]
  const type = req.query.type
  const EPSFcode = `${BU}/${'F44'}`
  const ASFcode = `${BU}/${'F26'}`
  let append = type == "VOTER" ? "@R_VID" : "@R_PAN"
  // console.log(JSON.parse(body).relation)
  let EPSinputPayload = {
      "fcode": EPSFcode,
      "data": {
        "Idnum": body.newPanNumber,
        "Remarks": body.remarks,
        "Subty": body.subType
     },
     "uniqueNo": uniqueNo
  }

  console.log('savePanDetails=======>', EPSinputPayload, EPSFcode)
  let saveVaultData = { "uniqueNo": uniqueNo, "cookie": cookie, "module": config.moduleCode }
  const PDSvaultData = new moduleVaults(saveVaultData)
  await PDSvaultData.save((PDSerr, value) => {
    if (PDSerr) {
      console.log("Error while saving vaultData in mongodb : ", PDSerr)
    } else {
      console.log("vaultData saved successfully in mongo db")
    }
  })
  await delfile(delatt, BU, type, uniqueNo,cookie)

  await attfile(file, cookie, BU, uniqueNo,append)

  await postNodeOData(EPSinputPayload, cookie)
    .then((EPSresult) => {
      let output = {}
      if(EPSresult && EPSresult.message != "Created" && EPSresult.message != "")
        EPSresult = JSON.parse(EPSresult.message)

      if(EPSresult && EPSresult.error)
        output = {systemErrMsg:EPSresult.error.message.value,responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      else
        output = {responseErrMsg:"",responseStatus:"SUCCESS"}
      logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, EPSFcode,"savePanDetails - " + "15", uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
      addLogInAPM(uniqueNo, EPSFcode, inTime, 1, "savePanDetails - " + "15 - "+"Interface Calling")
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, output)
    })
    .catch((EPSerror) => {
      console.log(EPSerror)
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

async function delfile(delatt, BU, type, uniqueNo,cookie){
  if(delatt.length>0){
    let mAppend = type == "VOTER" ? "R_VID" : "R_PAN"
    return await Promise.all(
      delatt.map(async (delrec)=>{
        let ALSFcode = `${BU}/${'F45'}`
        let ALSinputPayload = {
          "method":"DELETE",
          "queryparam":"?param=(Docid='"+delrec+"',Fieldname='"+mAppend+"')",
          "fcode": ALSFcode,
          "uniqueNo": uniqueNo
        }
        await postNodeOData(ALSinputPayload, cookie)
          .then((ALSresult) => {
            console.log("Attachment successfully ",ALSresult)  
            return delrec
          })
          .catch((ALSerror) => {
            console.log("Error in deleting attachment ",ALSerror)
            return delrec
          })
      })
    )
  }
  else return
}

async function attfile(file, cookie, BU, uniqueNo,append){
  if (file && file.length > 0) {
    let ASfileData = await fileuploadCall(file, cookie, BU, uniqueNo,append)
    if (ASfileData && ASfileData.EX_PAYLOAD && ASfileData.EX_PAYLOAD.ET_RETURN && ASfileData.EX_PAYLOAD_JSON.ET_RETURN.length && ASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].TYPE != "S") {
      console.log("Error in updating attachment ", ASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE);
      // return httpResponseHandlerError(res, 400, filesave.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE)
      return
    }
    else{
      console.log("Attachment successfully Created")
      return
    }
  }
  else return
}

module.exports.savePanDetails = savePanDetails
