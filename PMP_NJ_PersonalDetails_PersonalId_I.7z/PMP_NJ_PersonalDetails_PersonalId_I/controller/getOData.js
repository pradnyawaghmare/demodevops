/**
 * this function is wrapper for calling get odata service api to get data
 */
const getNodeOData = require('../services/getNodeOData').getNodeOData

async function getAbsenceDays (req, res) {
  const cookie = req.headers.cookie
  const paramString = req.query.param
  // depend on business fcode and busniess unit will get change
  const fcode = 'HC/F01'
  const apiUrl = `fcode=${fcode}&param=${paramString}`
  console.log('apiUrl', apiUrl)
  getNodeOData(apiUrl, cookie)
    .then((result) => {
      httpResponseSuccessHandler(res, result.statusCode, result.message, result)
    })
    .catch((error) => {
      httpResponseHandlerError(res, error.code, error.message)

    })
}

module.exports.getAbsenceDays = getAbsenceDays
