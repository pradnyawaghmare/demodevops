/**
 * this function is wrapper for calling producer service api to produce data into kafka
 */

let produceData = require('../services/produceData').produceData

function produceIntoKafka(req, res) {
  let inputPayload = req.body
  inputPayload.cookie = req.headers.cookie

  produceData(inputPayload)
    .then((result) => {
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, result)
    })
    .catch((error) => {
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, error)
    })
}

module.exports.produceIntoKafka = produceIntoKafka