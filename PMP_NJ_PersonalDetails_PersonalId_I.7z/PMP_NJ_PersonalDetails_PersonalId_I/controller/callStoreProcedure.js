/**
 * this function is wrapper for calling redis service api to read data
 */

let executeSP = require('../services/executeStoreProcedure').executeSP

function callSP(req, res){
    let inputPayload = req.body
    executeSP(inputPayload)
    .then((result) => {
        httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, result)
    })
    .catch((error) => {
        httpResponseHandlerError(res, msgCodeJson.ERR008.code, error)
    })
}

module.exports.callSP = callSP