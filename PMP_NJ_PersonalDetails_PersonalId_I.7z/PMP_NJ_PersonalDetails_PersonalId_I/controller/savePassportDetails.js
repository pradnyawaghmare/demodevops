const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
let { postNodeOData,fileUploadOdata } = require('../services/postNodeOdata')
const { callUploadToDMSAPI,addLogInAPM,fileuploadCall } = require('../services/commmon')
const moduleVaults = require('../model/MongoDBQuery/moduleVault')

async function savePassportDetails(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf();
  const uniqueNo = config.moduleCode + uniqId
  const inTime = new Date().toLocaleString()
  const BU = req.info.business_unit
  const file = req.files && req.files.length ? req.files : []
  const body = JSON.parse(req.body.jsonString)
  const delPD = req.body.deleteAttachmentList && req.body.deleteAttachmentList.length>0?req.body.deleteAttachmentList.split(","):[]
  const PDFcode = `${BU}/${'F69'}`
  const PDASFcode = `${BU}/${'F26'}`
  const issueDate = parseInt(body.issueDate) + 19800000
  const expiryDate = parseInt(body.expirationDate) + 19800000

  let PDinputPayload = {
      "fcode": PDFcode,
      "data": {
        "PassNum":body.passportNumber,
        "IssDate":"\/Date("+issueDate+")\/",
        "ExpDate":"\/Date("+expiryDate+")\/",
        "PlaceOfIss":body.placeOfIssue,
        "NameOnPass":body.nameOnPassport
      },
     "uniqueNo": uniqueNo
  }

  console.log('savePassportDetails=======>', PDinputPayload, PDFcode)
  let saveVaultData = { "uniqueNo": uniqueNo, "cookie": cookie, "module": config.moduleCode }
  const PDvaultData = new moduleVaults(saveVaultData)
  await PDvaultData.save((PDerr, value) => {
    if (PDerr) {
      console.log("Error while saving vaultData in mongodb : ", PDerr)
    } else {
      console.log("vaultData saved successfully in mongo db")
    }
  })
  if (file && file.length > 0) {
    let PDASfileData = await fileuploadCall(file, cookie, BU, uniqueNo,"@R_PASSPORT")
    if (PDASfileData && PDASfileData.EX_PAYLOAD && PDASfileData.EX_PAYLOAD.ET_RETURN && PDASfileData.EX_PAYLOAD_JSON.ET_RETURN.length && PDASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].TYPE != "S") {
      console.log("Error in updating attachment ", PDASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE);
      // return httpResponseHandlerError(res, 400, filesave.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE)
    }
    else{
      console.log("Attachment successfully Created")
    }
    // const VDASfileData = await callUploadToDMSAPI(file);
    // if (VDASfileData.OPStatus.StatusType === 'S') {
    //   let VDASpayload = {
    //     "fcode": VDASFcode,
    //     "headers":{
    //       "slug":VDASfileData.data.originalname+"@R_VISA",
    //       "Content-Type": req.file.mimetype,
    //       "content-transfer-encoding": 'Base64'
    //     },
    //     "data":{
    //       "content": req.file.buffer.toString('base64'),
    //     },
    //     "uniqueNo": uniqueNo
    //   }
    //   fileUploadOdata(VDASpayload, cookie)
    //     .then((VDASresult) => {
    //       console.log("Attachment successfully ",VDASresult.message)  
    //     })
    //     .catch((VDASerror) => {
    //       console.log("Error in updating attachment ",VDASerror)      
    //     })
    //   console.log("Uploaded to DMS")
    // }
  }
  if(delPD.length>0){
    delPD.forEach((delrecPD)=>{
      let PDALSFcode = `${BU}/${'F45'}`
      let PDALSinputPayload = {
        "method":"DELETE",
        "queryparam":"?param=(Docid='"+delrecPD+"',Fieldname='R_PASSPORT')",
        "fcode": PDALSFcode,
        "uniqueNo": uniqueNo
      }
      postNodeOData(PDALSinputPayload, cookie)
        .then((PDALSresult) => {
          console.log("Attachment successfully ",PDALSresult)  
        })
        .catch((PDALSerror) => {
          console.log("Error in deleting attachment ",PDALSerror)      
        })
    })
  }
  postNodeOData(PDinputPayload, cookie)
    .then((PDresult) => {
      let output = {}
      if(PDresult && PDresult.code && PDresult.code != 302)
        PDresult = JSON.parse(PDresult.message)
      if(PDresult && PDresult.error)
        output = {systemErrMsg:PDresult.error.message.value,responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      else
        output = {responseErrMsg:"",responseStatus:"SUCCESS"}
      logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, PDFcode,"savePassportDetails - " + "15", uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
      addLogInAPM(uniqueNo, PDFcode, inTime, 1, "savePassportDetails - " + "15 - "+"Interface Calling")
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, output)
    })
    .catch((PDerror) => {
      console.log(PDerror)
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

module.exports.savePassportDetails = savePassportDetails
