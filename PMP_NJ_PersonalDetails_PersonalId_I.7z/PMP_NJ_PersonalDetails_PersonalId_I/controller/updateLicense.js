const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
let { postNodeOData,fileUploadOdata } = require('../services/postNodeOdata')
const { callUploadToDMSAPI,addLogInAPM,fileuploadCall } = require('../services/commmon')
const moduleVaults = require('../model/MongoDBQuery/moduleVault')

async function updateLicense(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf();
  const uniqueNo = config.moduleCode + uniqId
  const inTime = new Date().toLocaleString()
  const BU = req.info.business_unit
  const file = req.files && req.files.length ? req.files : []
  const body = JSON.parse(req.body.licenseRequest)
  const delUDL = req.body.deleteAttachmentList && req.body.deleteAttachmentList.length>0?req.body.deleteAttachmentList.split(","):[]
  const licenseType = req.body.licenseType ? req.body.licenseType : ""
  const UDLFcode = `${BU}/${'F74'}`
  const UDLASFcode = `${BU}/${'F26'}`
  const issueDate = parseInt(body.issueDate) + 19800000
  const expiryDate = parseInt(body.expiryDate) + 19800000

  let UDLinputPayload = {
      "fcode": UDLFcode,
      "queryparam":"?param=(Ictyp='"+licenseType+"')",
      "method":"PUT",
      "data": {
        "Iscot":body.countryCode,
        "Isspl":body.issuePlace,
        "Expid":"\/Date("+expiryDate+")\/",
        "Fpdat":"\/Date("+issueDate+")\/",
        "Auth1":body.issueAuthority,
        "ImUser":"",
        "Ictyp":body.licenseType,
        "Icnum":body.licenseNumber
      },
     "uniqueNo": uniqueNo
  }

  console.log('updateLicense=======>', UDLinputPayload, UDLFcode)
  let saveVaultData = { "uniqueNo": uniqueNo, "cookie": cookie, "module": config.moduleCode }
  const UDLvaultData = new moduleVaults(saveVaultData)
  await UDLvaultData.save((UDLerr, value) => {
    if (UDLerr) {
      console.log("Error while saving vaultData in mongodb : ", UDLerr)
    } else {
      console.log("vaultData saved successfully in mongo db")
    }
  })
  if (file && file.length > 0) {
    let UDLASfileData = await fileuploadCall(file, cookie, BU, uniqueNo,"@R_DRV06")
    if (UDLASfileData && UDLASfileData.EX_PAYLOAD && UDLASfileData.EX_PAYLOAD.ET_RETURN && UDLASfileData.EX_PAYLOAD_JSON.ET_RETURN.length && UDLASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].TYPE != "S") {
      console.log("Error in updating attachment ", UDLASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE);
      // return httpResponseHandlerError(res, 400, filesave.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE)
    }
    else{
      console.log("Attachment successfully Created")
    }
    // const VDASfileData = await callUploadToDMSAPI(file);
    // if (VDASfileData.OPStatus.StatusType === 'S') {
    //   let VDASpayload = {
    //     "fcode": VDASFcode,
    //     "headers":{
    //       "slug":VDASfileData.data.originalname+"@R_VISA",
    //       "Content-Type": req.file.mimetype,
    //       "content-transfer-encoding": 'Base64'
    //     },
    //     "data":{
    //       "content": req.file.buffer.toString('base64'),
    //     },
    //     "uniqueNo": uniqueNo
    //   }
    //   fileUploadOdata(VDASpayload, cookie)
    //     .then((VDASresult) => {
    //       console.log("Attachment successfully ",VDASresult.message)  
    //     })
    //     .catch((VDASerror) => {
    //       console.log("Error in updating attachment ",VDASerror)      
    //     })
    //   console.log("Uploaded to DMS")
    // }
  }
  if(delUDL.length>0){
    delUDL.forEach((delrecUDL)=>{
      let UDLALSFcode = `${BU}/${'F45'}`
      let UDLALSinputPayload = {
        "method":"DELETE",
        "queryparam":"?param=(Docid='"+delrecUDL+"',Fieldname='R_DRV06')",
        "fcode": UDLALSFcode,
        "uniqueNo": uniqueNo
      }
      postNodeOData(UDLALSinputPayload, cookie)
        .then((UDLALSresult) => {
          console.log("Attachment successfully ",UDLALSresult)  
        })
        .catch((UDLALSerror) => {
          console.log("Error in deleting attachment ",UDLALSerror)      
        })
    })
  }
  postNodeOData(UDLinputPayload, cookie)
    .then((UDLresult) => {
      let output = {}
      if(UDLresult && UDLresult.message && UDLresult.message != "Created")
        UDLresult = JSON.parse(UDLresult.message)
      if(UDLresult && UDLresult.error)
        output = {systemErrMsg:UDLresult.error.message.value,responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      else
        output = {responseErrMsg:"",responseStatus:"SUCCESS"}
      logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, UDLFcode,"updateLicense - " + "15", uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
      addLogInAPM(uniqueNo, UDLFcode, inTime, 1, "updateLicense - " + "15 - "+"Interface Calling")
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, output)
    })
    .catch((UDLerror) => {
      console.log(UDLerror)
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

module.exports.updateLicense = updateLicense
