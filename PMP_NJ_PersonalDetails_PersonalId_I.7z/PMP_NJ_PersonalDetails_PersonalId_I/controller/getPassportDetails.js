const getNodeOData = require('../services/getNodeOData').getNodeOData;
const apmDetails = require('../utils/KIBANA/APM/apm');
const logs = require('../services/mongoLogger').mongoLog;
const addLogInAPM = require('../services/commmon').addLogInAPM;
const rTime = require('../services/commmon');

async function getPassportDetails(req, res) {
	const cookie = req.headers.cookie;
	const uniqId = new Date().valueOf();
	const uniqueNo = config.moduleCode + uniqId;
	const inTime = rTime.returnTime();
	const ppdfcode = 'F02';
	const BU = req.info.business_unit;

	const apiUrl = `fcode=${BU}/${ppdfcode}`;
	getNodeOData(apiUrl, cookie)
		.then((ppdresult) => {
			console.log('passport odata log ', ppdresult);
			if (ppdresult.body && ppdresult.body.d) {
				const output = returnFormateOut(ppdresult.body.d);
				logs(
					apmDetails.globalLabels.platform,
					apmDetails.globalLabels.sub_platform,
					BU + '/' + ppdfcode,
					'getPassportDetails - ' + '15',
					uniqueNo,
					apmDetails.globalLabels.application,
					apmDetails.globalLabels.component_type,
					1,
					'Interface Calling',
					inTime
				);
				addLogInAPM(uniqueNo, ppdfcode, inTime, 1, 'Interface Calling');
				httpResponseSuccessHandler(res, ppdresult.statusCode, ppdresult.message, output);
			} else {
				httpResponseHandlerError(res, msgCodeJson.ERR002.code, msgCodeJson.ERR002.msg);
			}
		})
		.catch((ppderror) => {
			console.log(ppderror);
			httpResponseHandlerError(res, ppderror.code, ppderror.message);
		});
}

function returnFormateOut(obj) {
	let outPutResult = {};

	outPutResult.user = obj.ImUser;
	outPutResult.passportNumber = obj.PassNum;
	outPutResult.issueDate = obj.IssDate ? parseInt(obj.IssDate.slice(obj.IssDate.indexOf('(') + 1, obj.IssDate.indexOf(')'))) : obj.IssDate;
	outPutResult.expirationDate = obj.ExpDate ? parseInt(obj.ExpDate.slice(obj.ExpDate.indexOf('(') + 1, obj.ExpDate.indexOf(')'))) : obj.ExpDate;
	outPutResult.placeOfIssue = obj.PlaceOfIss;
	outPutResult.nameOnPassport = obj.NameOnPass;
	outPutResult.remarks = obj.Remarks;

	return outPutResult;
}

module.exports.getPassportDetails = getPassportDetails;
