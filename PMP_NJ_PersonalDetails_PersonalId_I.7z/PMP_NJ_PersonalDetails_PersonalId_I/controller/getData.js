/**
 * this function is wrapper for calling fetch service api to get data
 */

const getData = require('../services/getData').getData

function getDetails (req, res) {
  const inputPayload = req.body
  req.headers.host = 'dev-hrplatform.ril.com'
  console.log('req headers get data', req.headers)
  getData(inputPayload)
    .then((result) => {
      console.log('result', JSON.stringify(result))
      if(result.result){
        httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, result.result)
      } else {
        httpResponseHandlerError(res, msgCodeJson.ERR008.code, result.message)
      }
    })
    .catch(() => {
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

module.exports.getDetails = getDetails
