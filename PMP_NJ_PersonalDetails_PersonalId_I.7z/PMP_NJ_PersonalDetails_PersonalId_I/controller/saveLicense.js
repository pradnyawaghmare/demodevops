const apmDetails = require('../utils/KIBANA/APM/apm')
const logs = require('../services/mongoLogger').mongoLog
let { postNodeOData,fileUploadOdata } = require('../services/postNodeOdata')
const { callUploadToDMSAPI,addLogInAPM,fileuploadCall } = require('../services/commmon')
const moduleVaults = require('../model/MongoDBQuery/moduleVault')

async function saveLicense(req, res) {
  const cookie = req.headers.cookie
  const uniqId = new Date().valueOf();
  const uniqueNo = config.moduleCode + uniqId
  const inTime = new Date().toLocaleString()
  const BU = req.info.business_unit
  const file = req.files && req.files.length ? req.files : []
  const body = JSON.parse(req.body.licenseRequest)
  const delDL = req.body.deleteAttachmentList && req.body.deleteAttachmentList.length>0?req.body.deleteAttachmentList.split(","):[]
  const DLFcode = `${BU}/${'F74'}`
  const DLASFcode = `${BU}/${'F26'}`
  const issueDate = parseInt(body.issueDate) + 19800000
  const expiryDate = parseInt(body.expiryDate) + 19800000

  let DLinputPayload = {
      "fcode": DLFcode,
      "data": {
        "Iscot":body.countryCode,
        "Isspl":body.issuePlace,
        "Expid":"\/Date("+expiryDate+")\/",
        "Fpdat":"\/Date("+issueDate+")\/",
        "Auth1":body.issueAuthority,
        "ImUser":"",
        "Ictyp":body.licenseType,
        "Icnum":body.licenseNumber
      },
     "uniqueNo": uniqueNo
  }

  console.log('saveLicense=======>', DLinputPayload, DLFcode)
  let saveVaultData = { "uniqueNo": uniqueNo, "cookie": cookie, "module": config.moduleCode }
  const DLvaultData = new moduleVaults(saveVaultData)
  await DLvaultData.save((DLerr, value) => {
    if (DLerr) {
      console.log("Error while saving vaultData in mongodb : ", DLerr)
    } else {
      console.log("vaultData saved successfully in mongo db")
    }
  })
  if (file && file.length > 0) {
    let DLASfileData = await fileuploadCall(file, cookie, BU, uniqueNo,"@R_DRV06")
    if (DLASfileData && DLASfileData.EX_PAYLOAD && DLASfileData.EX_PAYLOAD.ET_RETURN && DLASfileData.EX_PAYLOAD_JSON.ET_RETURN.length && DLASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].TYPE != "S") {
      console.log("Error in updating attachment ", DLASfileData.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE);
      // return httpResponseHandlerError(res, 400, filesave.EX_PAYLOAD_JSON.ET_RETURN[0].MESSAGE)
    }
    else{
      console.log("Attachment successfully Created")
    }
    // const VDASfileData = await callUploadToDMSAPI(file);
    // if (VDASfileData.OPStatus.StatusType === 'S') {
    //   let VDASpayload = {
    //     "fcode": VDASFcode,
    //     "headers":{
    //       "slug":VDASfileData.data.originalname+"@R_VISA",
    //       "Content-Type": req.file.mimetype,
    //       "content-transfer-encoding": 'Base64'
    //     },
    //     "data":{
    //       "content": req.file.buffer.toString('base64'),
    //     },
    //     "uniqueNo": uniqueNo
    //   }
    //   fileUploadOdata(VDASpayload, cookie)
    //     .then((VDASresult) => {
    //       console.log("Attachment successfully ",VDASresult.message)  
    //     })
    //     .catch((VDASerror) => {
    //       console.log("Error in updating attachment ",VDASerror)      
    //     })
    //   console.log("Uploaded to DMS")
    // }
  }
  if(delDL.length>0){
    delDL.forEach((delrecDL)=>{
      let DLALSFcode = `${BU}/${'F45'}`
      let DLALSinputPayload = {
        "method":"DELETE",
        "queryparam":"?param=(Docid='"+delrecDL+"',Fieldname='R_DRV06')",
        "fcode": DLALSFcode,
        "uniqueNo": uniqueNo
      }
      postNodeOData(DLALSinputPayload, cookie)
        .then((DLALSresult) => {
          console.log("Attachment successfully ",DLALSresult)  
        })
        .catch((DLALSerror) => {
          console.log("Error in deleting attachment ",DLALSerror)      
        })
    })
  }
  postNodeOData(DLinputPayload, cookie)
    .then((DLresult) => {
      let output = {}
      if(DLresult && DLresult.message && DLresult.message != "Created")
        DLresult = JSON.parse(DLresult.message)
      if(DLresult && DLresult.error)
        output = {systemErrMsg:DLresult.error.message.value,responseErrMsg:"Sorry for the inconvenience.",responseStatus:"FAILED"}
      else
        output = {responseErrMsg:"",responseStatus:"SUCCESS"}
      logs(apmDetails.globalLabels.platform, apmDetails.globalLabels.sub_platform, DLFcode,"saveLicense - " + "15", uniqueNo, apmDetails.globalLabels.application, apmDetails.globalLabels.component_type, 1, 'Interface Calling', inTime)
      addLogInAPM(uniqueNo, DLFcode, inTime, 1, "saveLicense - " + "15 - "+"Interface Calling")
      httpResponseSuccessHandler(res, msgCodeJson.ERR004.code, msgCodeJson.ERR004.msg, output)
    })
    .catch((DLerror) => {
      console.log(DLerror)
      httpResponseHandlerError(res, msgCodeJson.ERR008.code, msgCodeJson.ERR008.msg)
    })
}

module.exports.saveLicense = saveLicense
