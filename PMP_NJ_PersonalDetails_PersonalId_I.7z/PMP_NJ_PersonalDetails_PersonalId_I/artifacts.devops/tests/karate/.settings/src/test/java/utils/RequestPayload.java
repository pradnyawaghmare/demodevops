package utils;

import net.minidev.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class RequestPayload {
    
	public static JSONObject getValues(Long sDate) {

		JSONObject json = new JSONObject();
		json.put("workDate", sDate);
		json.put("actualIn", sDate);
		json.put("actualOut", sDate);
		json.put("regIn", sDate);
		json.put("regOut", sDate);
		json.put("leaveStartDate", sDate);
		json.put("leaveEndDate", sDate);
		return json;

	}
	
	public static void getValuesFromJSONFile() throws FileNotFoundException, IOException, ParseException {
		
		JSONParser jsonParser = new JSONParser();
		JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader(
                "delete_01.json"));
		
		for (Object o : jsonArray) {
            JSONObject pathDetails = (JSONObject) o;
            
            
            String betaPath = (String) pathDetails.get("path");
            System.out.println("BetaName::::" + betaPath);

            String prodPath = (String) pathDetails.get("path");
            System.out.println("ProdName::::" + prodPath);

            
            }
            

        }
		
	

}
