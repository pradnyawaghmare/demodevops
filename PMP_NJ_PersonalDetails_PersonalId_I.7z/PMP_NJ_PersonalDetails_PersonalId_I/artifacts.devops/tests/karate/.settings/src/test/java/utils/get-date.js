function fn(){

var today = new Date();
var date = today.getMonth()+1 + ":" + today.getFullYear() ;
return date

}

