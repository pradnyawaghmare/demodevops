 function fn(obj){
      		
   for ( var i =0; i< obj.length; i++){
       			
       if(obj[i].leaveApplied == "" && obj[i].attStatus == "ABS" && 
       	  obj[i].isLeave == false && obj[i].isRegularize == false ) {
       	
       			   return obj[i].shiftEndTime
       			  
       		}
        }
  }
  
  