function fn(){
	
	var config = {
	  env : 'prod',
	  resPath : 'hrservices/api/',
	  userId  : 'P10070772',
	  emailId : 'ajay.biswal',
	  appSessionId : 'NjQ3ZmM3NDUxNGNmMzI1YTdlZWFkMjFjMjhkZjk4ODU6OjZhN2JhMjc4MWY3YjRjYmI3MTg0YjgwOTgxY2ZkYmRlOjpHOE5Kc1lkM2F3SXFtRCtXQ1ZjT2tCQTZHdmxIcmppY1hQd1I0MllpUHBzPQ==',
	  
	  mySAPSSO2 : 'AjQxMDMBABhQADEAMAAwADcAMAA3ADcAMgAgACAAIAACAAY1ADgANgADABBOAEcAUAAgACAAIAAgACAABAAYMgAwADIAMQAwADIAMgA0ADEANAAxADYABQAEAAAACAkAAkUA%2fwFVMIIBUQYJKoZIhvcNAQcCoIIBQjCCAT4CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGCAR0wggEZAgEBMG8wZDELMAkGA1UEBhMCREUxHDAaBgNVBAoTE1NBUCBUcnVzdCBDb21tdW5pdHkxEzARBgNVBAsTClNBUCBXZWIgQVMxFDASBgNVBAsTC0kwMDIwMjYwNjU5MQwwCgYDVQQDEwNOR1ACByASCAgHUCQwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIxMDIyNDE0MTYzOVowIwYJKoZIhvcNAQkEMRYEFIteKrekiPZlwJWYzvrHH1rA9mYaMAkGByqGSM44BAMELjAsAhRqjXqK5iS8rdsfBanJhNMGIL88vgIUPa9HhsidFzlqhjVgNvx7wYzRijw%3d'
	};
	
	var env = karate.env;
	karate.log('karate.env system property is:', env);
	
	if(!env){
	   
	   env = 'prod';
	
	}
	
	if(env == 'qa'){
	   config.baseUrl = 'https://uat-hrplatform.ril.com/'
	   
	}
	else if (env == 'beta'){
	   config.baseUrl = 'https://beta-hrplatform.ril.com/'
	   
	
	}
	else if (env == 'prod'){
	   config.baseUrl = 'https://hrplatform.ril.com/'
	
	}
	
	
	karate.configure('ssl', true);
    
	
	return config;
	
    
}

