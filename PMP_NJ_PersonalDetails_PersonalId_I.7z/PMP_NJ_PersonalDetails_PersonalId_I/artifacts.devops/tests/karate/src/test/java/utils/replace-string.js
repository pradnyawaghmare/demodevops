function replaceString(str){
var res= str.toString().replace("[", "").replace("]", "") ;
return res

}