package utils;

import net.minidev.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class RequestPayload {
    
	public static JSONObject getValues(Long sDate) {

		JSONObject json = new JSONObject();
		json.put("workDate", sDate);
		json.put("actualIn", sDate);
		json.put("actualOut", sDate);
		json.put("regIn", sDate);
		json.put("regOut", sDate);
		json.put("leaveStartDate", sDate);
		json.put("leaveEndDate", sDate);
		return json;

	}
	
	public static JSONObject getCompensation(String sValue) {

		JSONObject json = new JSONObject();
		json.put("count", sValue);
		json.put("effectiveDate", sValue);
		json.put("reasonCode", sValue);
		json.put("reasonSubCode", sValue);
		json.put("type", sValue);
		json.put("year", sValue);
		return json;

	}
	
	
}
