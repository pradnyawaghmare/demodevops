package utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JsonReader {
	
	public static Object getValuefromJsonFile(String envName) throws FileNotFoundException, IOException, ParseException  {
		
		JSONParser jsonParser = new JSONParser();
		Object obj = jsonParser.parse(new FileReader("C:\\Karate\\Karate-API-Framework\\src\\test\\java\\service\\testdata\\authService.json"));
		JSONObject jsonObject = (JSONObject) obj;
		Object pathValue=jsonObject.get(envName).toString();
		return ((String) pathValue).split(":")[1].replaceAll("}", "");
		
		
		
	}
	
	
	

}
