function fn(){
	
	var config = {
	  resPath : 'pmpapi/',
	  expectedStatus: 200
	  

	};
	
	var env = karate.env;
	karate.log('karate.env system property is:', env);
	
	if(!env){

	   env = 'preprod';
	
	}
	
	if(env == 'dev'){
	   
	   config.baseUrl = 'http://hrplatformdev.ril.com/'
	   config.empid = 'dv.19507440'
	   config.pass = 'Ril@1234'
	   config.searchEmp = 'tej'
	   config.nomEmp = 'dv.30502947'
	   
	}
	else if (env == 'qa'){
	   config.baseUrl = 'https://hrplatformqa.ril.com/'
	   config.empid = 'qa.19507440'
	   config.pass = 'Ril@1234'
	   config.searchEmp = '00667403'
	   config.nomEmp = 'qa.30502947'
	 
	}
	else if (env == 'preprod'){
	   config.baseUrl = 'https://hrplatformppd.ril.com/'
	   config.empid = 'pp.10053685'
	   config.pass = 'Ril@1234'
	   config.searchEmp = '00667403'
	   config.nomEmp = 'pp.30502947'
	}

	else if (env == 'prod'){
    	   config.baseUrl = 'https://hrplatformprod.ril.com/'

    	}

	else if (env == 'hotfix'){
		   // baseURl need to confirm
			config.baseUrl = 'https://hrplatformprod.ril.com/'
 
	    }
	
	karate.configure('ssl', { trustAll: true });
	karate.configure('logPrettyRequest', true);
	karate.configure('logPrettyResponse', true);
	
	return config;
	
    
}

