const mongoose = require('mongoose')
const Schema = mongoose.Schema

const modulelogsSchema = new Schema({
    moduleCode: {
        type: String
    },
    uniqueNo: {
        type: String
    },
    payload: {
        type: String,
    },
    topic: {
        type: String,
    },
    offset: {
        type: String,
    },
    partition: {
        type: String,
    },
    status: {
        type: String,
    },
    remark: {
        type: String,
    }

}, {
    timestamps: true,
})

const moduleLogs = mongoose.model('modulelogs', modulelogsSchema)
module.exports = moduleLogs
