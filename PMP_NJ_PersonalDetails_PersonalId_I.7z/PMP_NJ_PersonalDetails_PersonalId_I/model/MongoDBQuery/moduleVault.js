const mongoose = require('mongoose')
const Schema = mongoose.Schema

const modulevaultSchema = new Schema({
    uniqueNo: {
        type: String
    },
    cookie: {
        type: String,
        default:""
    },
    module: {
        type: String,
    }
}, {
    timestamps: true,
})

const moduleVault = mongoose.model('modulevault', modulevaultSchema)
module.exports = moduleVault
